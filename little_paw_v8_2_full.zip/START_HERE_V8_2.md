# Little Paw V8.2 - Woodland Polish

This update is based on V8.1. All planner boards, task schedules, recurring habits, focus timers, coins, shop inventory, land limits, decorations and V8.1 save structure remain unchanged.

## What's changed

- All wooden nine-slice textures are redrawn with compact 6-pixel corners, fixing giant overlapping borders on small controls.
- Both the shared `pixel_theme.tres` and scene-local frame styles now use matching 6px margins.
- Forest zoom buttons (- / 100% / +) next to navigation arrows; forest zoom from 70% to 145%.
- Ctrl + mouse wheel over the forest zooms, Shift + mouse wheel pans; zoom does not affect the planner or shop.
- Sky background extended and tiled to avoid empty areas at the smallest zoom level.
- Mochi's mismatched walk frame was replaced with a consistent pose, walking cycle is smoother, and animation is integer-pixel aligned.

## Install

**Full project:** unzip into a new folder and import `project.godot` in Godot (use Import, not Install).
**Patch:** close Godot, back up your folder, extract patch into the folder containing `project.godot`, and allow same-name files to be replaced. The patch only contains changed files plus this guide.

**Important:** Back up `user://little_paw_save.json` as well before switching projects. Godot editor: Project -> Open User Data Folder. Full V8.2 project uses the same save format as V8.1.

## Test list

1. Open Planner: small Edit and Delete buttons have thin corner frames and remain legible.
2. Open Pet: try zoom +/- and Ctrl-wheel over forest; ensure zoom label updates.
3. Pan to plot 2 and zoom out; no black bars and Mochi walks normally.
4. Watch Mochi walk: no giant black outlined sprite frame should appear.
5. Buy/place/store a decoration; save & reopen; verify it persists.

## Edit in Godot

- UI textures: `assets/ui/wood_*.png` (64x64 source, 6px nine-slice margins)
- UI style: `assets/ui/pixel_theme.tres` plus per-scene style overrides
- Bear animations: `scenes/pet.tscn` and `assets/pets/bear_*.png`
- Forest zoom: `scenes/habitat_view.tscn` and `scripts/habitat_view.gd`

The project was checked for ZIP integrity, resource paths and common GDScript structure but has not been executed in the Godot editor in this environment.
