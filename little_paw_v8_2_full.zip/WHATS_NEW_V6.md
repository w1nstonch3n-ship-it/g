# Little Paw V6 — Planner usability overhaul

- New `scenes/task_editor.tscn`: central 2-column task editor with no internal scrolling.
- Editable fields for title, one-off vs daily, reward tier, board, due/start date and optional daily end date.
- Custom board tabs; add your own (up to 16 total), remove them safely, and keep them across sessions.
- New X button on every task card, including Completed, with a confirmation dialog.
- Daily habits remain in the Habits column when checked with an explicit “DONE TODAY - BACK TOMORROW” status.
- Completion/undo status messages make coin feedback clearer; checkbox UI uses dark brown text in all interaction states.
- Theme update for OptionButton text in normal, hovered, pressed, and focused states.
- Task and board data persists in `user://little_paw_save.json`. V5 save data is migrated with three default boards.
- Offline daily reset uses the OS local date, checked every 2 seconds when open and immediately on launch.

**What V6 doesn't include yet:** drag-and-drop organization, weekly recurrence, cloud sync, anti-clock-tampering checks, focus session persistence after fully quitting, or responsive narrow mobile UI. Those are separate future milestones.
