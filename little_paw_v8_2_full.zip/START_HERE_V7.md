# Little Paw V7 — Forest Edition

## Getting started
1. Extract the ZIP into a **new** folder.
2. Open Godot 4.7.2 Project Manager > Import > choose `project.godot`.
3. Press F5. Under **PET**, use `<` and `>` at the bottom of the forest to pan.
4. Complete a task to earn coins, then buy **Flowers**, **Cozy Bed**, **Pond**, or **More Land**. Each upgrade appears as an editable sprite in the habitat. More Land opens a second grove and extends Mochi's roaming area.
5. Open **PLANNER** to use the V6 one-time / scheduled / daily habits, custom boards, due dates and undo controls.
6. Under **FOCUS TIMER**, start, pause, reset, or complete study/break sessions.

## How to edit the artwork visually
- `scenes/habitat.tscn`: move the den, oak trees, flowers, bed, pond and new grove decorations. Each is a distinct Sprite2D node.
- `scenes/pet.tscn`: select BearSprite and open SpriteFrames to change Mochi's idle/walk/eat/sleep animations.
- `scenes/habitat_view.tscn`: change camera buttons, forest title and viewport frame.
- `scenes/main.tscn`: change the top navigation and right-hand nook.
- `scenes/shop_item.tscn`, `scenes/shop_panel.tscn`, `scenes/focus_panel.tscn`, `scenes/planner_board.tscn`: edit individual widgets and their positions.
- `assets/ui/pixel_theme.tres`: shared theme colors and button styles.

## Save data
This project retains the V6 GameState and uses `user://little_paw_save.json`. If V6/V6.2 was installed in a separate Godot project, copy that save file from V6's **Project > Open User Data Folder** into V7's user data folder with Godot closed. Back it up before copying. Godot may use the project name as the data directory, so do not expect the new project to load an old save automatically.

## Known limitations
- This is a desktop-first layout at 1200 x 740. Mobile and web exports need further responsive layout and interaction testing.
- The project assets are original sprite PNGs, deliberately editable independently.
- This package was checked statically but has not yet been run through the Godot editor here.
- This version intentionally keeps the V6 task and focus timer scripts. Active focus sessions are not persisted after app exit.
