# Little Paw V8 — Endless Woodland

This project targets Godot 4.7.2. Open project.godot using Godot > Import > Import & Edit.

## What changed
- Infinite-ish expandable horizontal forest: there is no fixed land plot cap in the game logic. Purchases increment a persisted count and the renderer creates only nearby plots.
- 31 upgrade types with sprites, prices, and categories, 29 of which can be purchased multiple times.
- Full wood-frame pixel UI theme and bordered card surfaces, plus updated decorative art.
- All V7 planner, focus-timer, and save logic carried over.

## Safe migration
GameState loads pre-V8 save JSON and migrates purchased boolean upgrades to counts. This project keeps the same save filename, but Godot may use a different user-data folder because this is a differently named project. For a standalone V8 import, copy `little_paw_save.json` from the old project User Data Folder into V8's User Data Folder with both games closed. For the code/UI patch installed over your existing V7 project (without replacing `project.godot`), your save location stays unchanged.

## Edit in Godot
- The opening habitat scene is `scenes/habitat.tscn` and is editor-visible.
- Plot objects are generated under `GeneratedForest` in the Remote scene tree at runtime.
- Theme images are in `assets/ui` and source theme at `assets/ui/pixel_theme.tres`.
- The shop catalog is defined in `scripts/game_state.gd`; reusable card appearance is `scenes/shop_item.tscn`.

## Verification
File paths, scene/resource references, ZIP integrity, and sprite presence were checked. Runtime Godot gameplay validation was not possible in the current environment.
