# V7 changes
- Complete visual art refresh: original forest panorama, den, trees, decorations and re-drawn Mochi frames.
- Expanded habitat: real side-to-side camera travel, gated second grove unlocked by More Land.
- Upgrade effects: bed replaces mat, flowers add two patches, pond appears, land opens new trees, mushrooms and lantern, pet can visit the bed and pond.
- Theme redesign: sage / moss / warm cream pixel-style UI, softer text and buttons, improved desktop viewport.
- Task logic, boards, due dates, daily reset, reward undo and delete-keeps-coins are inherited from V6.2.
- Timer logic and presets are inherited from V6.2.
- Existing V6 save JSON schema is preserved.
