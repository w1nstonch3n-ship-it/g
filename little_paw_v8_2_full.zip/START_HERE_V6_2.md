# Little Paw V6.2 — Shop & Focus Polish

## Recommended install for an existing V6 game
1. Back up the **entire** project directory and the local save at `user://little_paw_save.json` (Godot: Project > Open User Data Folder).
2. Close Godot.
3. Extract `little_paw_v6_2_shop_focus_patch.zip` into your project folder, preserving the `scenes/` and `scripts/` folders and accepting replacements.
4. Reopen your existing project in Godot 4.7.2, run F5, then check Shop and Focus.

The patch only includes shop and focus scenes/scripts and the main navigation script. The top pet header and decorative footer are hidden in the sidebar to give the shop/timer more room; it does not include `game_state.gd`, any planner/task files, or your art assets. **Your existing task deletion = keep coins fix stays untouched.**

## Where to edit the shop
- `scenes/shop_panel.tscn`: category tabs, care area, and card instances.
- `scenes/shop_item.tscn`: layout used by all 4 cards. Open it to change every item card.
- Select `BedCard`, `FlowersCard`, `PondCard`, `LandCard` in the shop scene to change the exported title, description, category and image in the Inspector.
- `scripts/shop_panel.gd`: tab filtering / buying / feeding.
- `scripts/shop_item.gd`: individual Buy button / Owned status.
- Prices remain in `scripts/game_state.gd` (unchanged).

## Focus timer
- Open `scenes/focus_panel.tscn` for layout.
- Entire panel is a ScrollContainer with its contents in `Content`, so smaller windows can scroll instead of clipping.
- Default 1080 x 640 view uses compact controls and should generally fit without scrolling.
- Timer remains active when switching to Planner or Shop.
- It does not persist a partially running session across fully quitting the game.

## Verification checklist
1. Buy bed. It says OWNED; the habitat shows the bed; save progress and reopen.
2. Switch between ALL / COZY / OUTDOORS. Feed is always visible.
3. With insufficient coins, Buy is disabled and displays the missing amount on hover.
4. Switch to Focus. The Start and Reset buttons should fit inside the panel.
5. Start the 1m timer, switch to Planner, switch back, finish and earn coins once.
6. Confirm you can delete a completed task while keeping its coins (assuming you installed your V6 deletion patch).

This project was statically inspected; it has not been run in a local Godot editor here.
