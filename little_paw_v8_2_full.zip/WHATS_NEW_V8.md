Little Paw V8 — Endless Woodland

- No fixed endpoint to land purchases; each new plot extends the scrolling forest.
- 31 items in the shop, most repeatable with incremental prices.
- Each purchased type adds visible objects to the forest; decorations are generated only near the player/camera for performance.
- Wood pixel-art UI frames, borders, buttons, text fields, and panels.
- Improved pixel-art furniture and decorations, warm forest atmosphere.
- Keeps V7 planner, focus, boards, due dates, task undo and save compatibility.
