# Little Paw V8.1 — Cozy Woodland

See **START_HERE_V8_1.md** for installation instructions, land pricing, inventory, selling, and testing. 

This release retains the planner and focus timer from V8. You can edit each scene in Godot.
