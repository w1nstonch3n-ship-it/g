# Little Paw v3 — Focus Mode (code update)

This is a **copy** of the original editable Godot project. It retains the separate habitat, pet, task, and shop scenes, and adds one new editable scene: `scenes/focus_panel.tscn`.

## New functionality
- A **FOCUS** tab: 1-, 5-, 25-, or 45-minute timer; start, pause, resume, reset.
- Focus sessions pay **2 coins per fully completed minute** (25 minutes = 50 coins). No coins from pausing/resetting.
- Completed focus-session count and total focus minutes are saved to the existing local save file.
- Mochi shows a happy heart when a session finishes.
- Your existing task, coin, and upgrade saves remain readable (new save fields default to zero).

## Avoid overwriting your art
If you've already edited your project's art, **back it up first**. The complete v3 ZIP is safest to test in a separate folder. To merge code into a customized v2 project, copy:

- `scripts/focus_panel.gd` (new)
- `scenes/focus_panel.tscn` (new)
- `scripts/game_state.gd` (changed, merge carefully if you changed prices)
- `scripts/main.gd` and `scenes/main.tscn` (changed, merge carefully if you changed sidebar UI)
- `scripts/pet.gd` (small new focus reaction)

No sprites, habitat scene, pixel theme, or other art was changed by this update. You can move/replace sprites in your own copy of the project without impacting the focus code.

## Test
1. Extract ZIP to a separate folder. Import its `project.godot`.
2. Press F5, click **FOCUS**, select **1m**, and click **START FOCUS**.
3. Switch to another tab and back. Timer should continue; when it reaches zero you get +2 coins and a heart reaction.
4. Test **PAUSE** and **RESET**; neither should award coins.
5. Close and reopen; focus totals, coins and purchases should persist.

Note: this timer counts elapsed time while the application is running, including when minimized. Quitting Godot mid-session resets that unfinished session. Browser background scheduling may differ. This is a prototype and does not claim to verify real-world studying.

## Runtime verification
The package was checked for archive integrity and resource references. Godot editor runtime is not installed in the file-building environment, so please report an error with a screenshot if your first F5 run fails.
