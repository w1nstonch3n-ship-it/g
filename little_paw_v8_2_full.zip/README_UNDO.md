# Little Paw V4.1 — Undo completed tasks

## Installation (for your existing FULL V4 project)
1. **Close Godot** and back up your Little Paw project folder.
2. Extract `little_paw_v4_1_undo_patch.zip`.
3. Copy the two files from its `scripts/` directory into your current project's `scripts/` directory. **Replace** `game_state.gd` and `task_row.gd` when prompted.
4. Reopen Godot and press F5.

Do not delete `user://little_paw_save.json`. Existing coins, tasks, focus sessions, and purchased habitat upgrades are preserved.

## How undo works
- Completed checkboxes stay clickable. Uncheck to undo completion and subtract its originally earned reward. Check again to re-earn it.
- One-time and Today tasks can be unchecked even after their due date (find them in ALL TASKS).
- Daily recurring tasks can only undo today's check. Rewards from prior days remain earned.
- Removing an already-checked task also reverses its currently reversible reward. Uncompleted task deletion has no coin effect.
- Editing a task's size *after completion* does not change the historical reward: undo subtracts what it actually granted.
- Editing a completed task from one-time to daily (or vice versa) resets completion and returns the current award.
- If you've already spent the earned coins on a bed or food, undo can show a negative coin balance. This is deliberate: your upgrades stay purchased, and future coins pay off the negative amount. You cannot buy anything else until you can afford it.
- Old V4 saves did not record individual task rewards. For old completed tasks only, the refund is estimated from the task's current size. New completions are recorded exactly.

## Quick test
1. Start with 100 coins (or note your current balance).
2. Create a Small task, complete it: +15.
3. Uncheck it: -15. Check it again: +15.
4. Complete a Huge task (+100), edit its size to Small, then uncheck: -100.
5. Complete a daily task, uncheck it the same day: its reward is reversed; checking again pays once.

This patch changes no scenes, sprite assets, habitat layouts, or UI art.
