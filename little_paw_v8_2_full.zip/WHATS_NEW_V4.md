# Little Paw V4 — Planner + Study Timers

This update adds real scheduling and task sizing to the existing editable Godot project.

## Tasks

1. Click **+ NEW TASK**.
2. Give the task a name.
3. Choose one of these modes:
   - **Today (one-time)**: due today, stays completed permanently; never repeats.
   - **Schedule once**: a one-time task with an optional due date. Future tasks show in **ALL TASKS** until their due date, then appear in **TODAY**. Overdue tasks remain completable.
   - **Repeat every day**: a habit due once per day, beginning on a start date (today by default). Optionally select an end date. Completion pays coins **once per local calendar day**, then becomes available the next day.
4. Choose a size **before** saving:
   - **Small**: +15 coins
   - **Medium**: +40 coins
   - **Huge**: +100 coins
5. Enter a date in `YYYY-MM-DD` or use the TODAY / +1 DAY / +7 DAYS shortcuts. Invalid dates are rejected.
6. Click **CREATE TASK**. To change its size, title, recurrence, or due date, click **EDIT** next to the task.

Changing a task's recurrence mode clears its completion state. Changing its other fields preserves completion and never pays retroactive coins. Deleting a task does not reclaim earned coins.

## Study timer

- **STUDY** sessions earn +2 coins per full minute. Choose 1, 5, 25, 45, or a custom 1–120 minute duration.
- **BREAK** sessions use the same timer but earn no coins.
- **PAUSE**, **RESUME**, **RESET** work from the Focus tab. Running timers continue counting down when switching tabs or minimizing the game, so long as the app stays open and processes normally.
- Finished study sessions count towards lifetime sessions, lifetime minutes, and today's minutes.
- An abandoned/uncompleted focus session does not receive coins.

## Compatibility with previous saves

Uses the same `user://little_paw_save.json` path as V2 and V3.
Existing coins, upgrades, pet happiness, focus statistics, and tasks are loaded.
Existing V3 tasks become **one-time Medium** tasks, preserving their completed status. New tasks support the richer scheduling fields.

If you want to test with a clean save, back up the existing JSON file and then remove the original. Do not delete your art files.

## Editability in Godot

- `scenes/task_panel.tscn`: task editor, date shortcuts, Today and All Tasks views
- `scenes/task_row.tscn`: row appearance, checkbox, edit and delete buttons
- `scenes/focus_panel.tscn`: study/break timer layout
- `scripts/game_state.gd`: tasks, reward amounts, dates, persistence, backward migration
- `scripts/task_panel.gd`: editing task details, validation and filtering
- `scripts/task_row.gd`: display one task
- `scripts/focus_panel.gd`: focus/break timer logic

### Keeping your custom pixel art

Use the **CODE + UI PATCH ZIP** to update your existing V3 project, not the full project ZIP. The patch contains only scripts and affected UI scenes. It does **not** include pet PNGs, habitat PNGs, `pet.tscn` or `habitat.tscn`, so they will stay unchanged.

**However**, the patch will replace task/focus panel scenes, including any UI edits you have made *inside those scenes*. Back up your project first and merge those scene edits manually if needed.

## Limitations of this prototype

- Dates are calendar dates, not times of day. No notification or calendar picker yet.
- Local device timezone governs daily reset.
- The focus countdown lives in memory; closing the app resets an unfinished session.
- No online sync yet; desktop, browser, and mobile saves are separate.
