# LITTLE PAW V8.1 — COZY POLISH

## Install
1. Back up your existing project folder and `little_paw_save.json` from Project > Open User Data Folder.
2. Extract the complete ZIP to a new directory and import `project.godot` from Godot Project Manager.
3. To apply changes to your customized V8 artwork, instead extract the update ZIP into the folder with `project.godot` and merge changes.
4. Press F5.

## Land purchase ladder (five expansions max)
Plot 1 300 coins; plot 2 1,200; plot 3 4,200; plot 4 12,000; plot 5 30,000. Starter clearing does not count against the five. Land can’t be sold.

## Decorating
* Buying a decoration adds it to your **bag** instead of immediately cluttering the habitat.
* Browse left/right to your desired clearing, then click **PLACE** on an owned item in the shop. Click **STORE** to return a placed item to your bag (without a refund or penalty).
* The starter clearing has two decoration slots, and each new plot has four. The default bed, wildflower patch and pond are built into the original clearing and do not consume a slot.
* **SELL** returns half of the latest item’s price; unplaced items sell first, otherwise the last placed instance disappears.
* Already-purchased V8 decorations are migrated into the new storage system, automatically placing at most four per clearing. Extras stay owned in your bag.
* Buying more land makes new open plots; Mochi **walks** to the plot you view instead of teleporting.

## Confirm the changes
* Create a task, collect coins, buy plot 1, observe plot 2 price.
* Purchase two benches, move camera to a new clearing, place one; sell the other.
* Close and reopen the game: coin balance, plots, and placement should persist.
* Open planner and focus timer: their functionality should be unchanged.

## Editing scenes
* `scenes/shop_item.tscn`: Buy/Place/Sell controls.
* `scripts/game_state.gd`: land prices, inventory, and refunds.
* `scripts/habitat.gd`: environment slots and forest generation.
* `assets/ui/pixel_theme.tres`: wood panel theme.

Godot was not available to run this project in the packaging environment, so please report any first-launch errors.
