# Little Paw V6 — Start here

## Install

**Keep your original V5 folder and save data as a backup.**

### Option A: keep your custom pet art (recommended)
1. Close Godot.
2. Duplicate your entire current Little Paw project folder as a backup.
3. Extract `little_paw_v6_code_ui_patch.zip`.
4. Copy its `scenes/`, `scripts/`, and `assets/ui/pixel_theme.tres` into the matching locations inside your existing Godot project, allowing files to replace existing ones. **Do not erase the rest of those folders.**
5. Reopen the project and open `scenes/main.tscn`, then press F5.

The patch contains no pet or habitat PNGs and does not replace `pet.tscn`, `habitat.tscn`, or your pixel-art sprites. It **does** replace `planner_board.tscn`, `board_card.tscn`, and `pixel_theme.tres`; back up customized versions of those UI files first.

### Option B: open a fresh copy
1. Extract `little_paw_v6_full_godot.zip` into a separate folder.
2. In Godot 4.7.2, click **Import** and select `project.godot` inside the extracted folder (don't use Godot's asset-package installer).
3. Press F5.

Both copies retain the same save-file mechanism. Your game progress is saved in Godot's `user://little_paw_save.json` folder. For safety, back up that JSON file via **Project > Open User Data Folder** before running the update.

## V6 navigation

**PET** is unchanged: Mochi, habitat, shop, focus timer.

**PLANNER** contains four columns:
- TODAY: due today, overdue, or no date
- UPCOMING: one-time work with a future deadline
- DAILY HABITS: active recurring habits, whether checked or unchecked (you'll see **DONE TODAY - BACK TOMORROW**)
- COMPLETED: finished one-time tasks

Click **+ BOARD** to create a custom tab. Click **REMOVE** on your custom tab to remove it; its tasks move to Personal instead of being deleted. School, Personal, and Projects remain as defaults.

Click **+ NEW TASK** to open the two-column editor. There is no ScrollContainer in this editor; title, type, difficulty, board, dates, help, and Save / Cancel share one panel. Select **Every day** for a repeating habit. For that kind, the first date is the start date and the optional end date ends the recurrence.

Each card has a checkbox, `...` to edit, and `X` to delete. Deletion requires confirmation. Uncheck a task to undo its latest reward. If you delete a checked one-time task, its current reward is also reversed. Previously earned daily rewards from earlier dates are not removed.

## Daily reset: offline explanation

- Godot reads the **device's own local system date** using `Time.get_date_string_from_system(false)`; Wi-Fi is not needed.
- The save records the **last_completed_date** on each daily habit.
- Each time the UI is shown, and every 2 seconds while the game is open, V6 compares today's date with the last completion date.
- A habit checked on Monday becomes unchecked on Tuesday. It can earn coins once again on Tuesday. Monday's coins stay earned.
- If the game is closed at midnight, the next launch reads the new date immediately. Nothing has to run in the background.
- If a computer's clock, time zone or date is wrong or manually altered, the local reset may occur at the wrong time. Cross-device anti-cheat/synchronization would need an online trusted clock later.
- **Focus study timers are separate.** They run without Wi-Fi while the app is open, but V6 does **not** continue an active focus timer after you fully close the app. It doesn't award coins for unverified time while closed.

## Scene tree to edit

```
scenes/main.tscn
  Main
    PetPage (unchanged)
    PlannerPage  -> scenes/planner_board.tscn
      BoardMargin/Stack
        Heading/NewTaskButton
        BoardBar/BoardScroll/BoardButtons  [dynamic board tabs]
        BoardBar/NewBoardButton
        BoardBar/DeleteBoardButton
        InfoLine
        ColumnRow
          TodayColumn
          UpcomingColumn
          HabitsColumn
          DoneColumn
      TaskEditor -> scenes/task_editor.tscn
        EditorPanel/Padding/Stack
          Heading
          NameInput
          FirstRow (kind + difficulty)
          SecondRow (board + date)
          ExtraRow (end date, daily only)
          QuickRow
          Buttons (Save + Cancel)
      DeleteTaskDialog
      DeleteBoardDialog
      NewBoardOverlay
```

Scripts:
- `scripts/game_state.gd`: persistent data, custom boards, task logic, due-date logic, rewards and daily resets
- `scripts/planner_board.gd`: tabs, task columns, delete confirmations, creation flow and completion messages
- `scripts/task_editor.gd`: the non-scrolling task editor
- `scripts/board_card.gd`: checkbox, delete and edit interactions

## Try these five tests

1. Make **Small / Just today**. Check it (+15), uncheck (-15), check it (+15), delete it (its 15 coins are reversed).
2. Create **Every day** called Journal, check it. It stays in Daily Habits and says **DONE TODAY - BACK TOMORROW**. On the next local calendar day (even after restarting the game), it is unchecked again, but yesterday's coins remain.
3. Create a custom **Soccer** board. Make a task inside it, quit and reopen, and verify both the board and task are still there.
4. Delete the Soccer board: its tasks move into **Personal**, not deleted.
5. Open **+ NEW TASK** and change between type selections. The Save button should always be visible, with no need to scroll.

If you get a Godot error, copy the **first red error message** and its script line number. This project was structurally checked but was not run inside the Godot editor in this environment.
