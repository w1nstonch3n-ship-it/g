# Little Paw V8 — Endless Woodland (Godot 4.7.2)

## Start here
1. Extract this ZIP in a new folder; do not overwrite your V7 art project.
2. In Godot 4.7.2 > Import, select `project.godot`, then press F5.
3. Open PET > SHOP: browse ALL / COZY / OUTDOORS / DECOR.
4. Buy another land plot. Use the forest arrows to travel to the new section.
5. Buy repeatable decorations; the purchased counts appear on the cards.
6. Open PLANNER and FOCUS to check that your V6/V7 workflows still operate.

## Editing
- Theme textures: `assets/ui/wood_*.png` and `assets/ui/pixel_theme.tres`.
- Shop card design: `scenes/shop_item.tscn`.
- Upgrade catalog/prices: `scripts/game_state.gd` in UPGRADE_CATALOG and UPGRADE_PRICES.
- Environment/procedural placement: `scripts/habitat.gd`.
- Forest camera/navigation: `scripts/habitat_view.gd`.
- Existing editor-visible opening clearing: `scenes/habitat.tscn`.
- New land plots: generated under `Habitat/GeneratedForest` in Remote Scene tree while game is running.

## Save compatibility
- Continues to use `user://little_paw_save.json`.
- Old V7 upgrade flags are migrated into count=1 on load.
- V8 saves store `upgrade_counts`; your boards, tasks, coins, and focus statistics are unchanged.
- Back up your save before importing into this version. A standalone project with a new app name may require copying the JSON to its user folder.

## Notes
- Infinite means there is no fixed gameplay limit on purchasable land; scene chunks are generated near the camera for performance, not an infinite map rendered at once.
- Coin pricing has a 25,000-coin ceiling so expansion stays achievable, but counts and saves remain bound by the computer's finite resources.
- Existing sprite assets remain editable. New decoration art is in assets/habitat.
- This project is statically validated, but has NOT been executed in the Godot editor in this environment.
