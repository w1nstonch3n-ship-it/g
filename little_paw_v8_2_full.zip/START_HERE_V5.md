# Little Paw V5 — How to use the new Planner

## Importing V5
1. BACK UP your existing Little Paw folder, and keep it for safety.
2. Extract `little_paw_v5_full.zip` into a separate folder.
3. In Godot, choose **Import**, then select `project.godot` from that folder.
4. Press F5. The new navigation bar has **PET** and **PLANNER** tabs.

### Best option if you've been editing the art in V4.1
Use `little_paw_v5_code_ui_patch.zip` instead of replacing your project folder. Close Godot, back up your folder, then copy the patch's `scenes`, `scripts`, and `assets/ui` files into your existing project. This does **not** replace `assets/habitat` or `assets/pets`. It will replace `scenes/main.tscn`, so if you moved your habitat nodes *in that scene*, merge those manually. Pet and habitat scene files remain unchanged.

## What to click
- PET: your existing habitat, shop and focus timer.
- PLANNER: a big board with four columns — TODAY, UPCOMING, DAILY HABITS, COMPLETED.
- ALL / SCHOOL / PERSONAL / PROJECTS: filter by board.
- + NEW TASK: enter its name, type, size, due date and the board.
- ... on any task card: edit its details or move it to another board.
- Checkbox: complete for coins; uncheck to undo that reward (same V4.1 rules).
- The focus timer keeps counting when you switch between PET and PLANNER tabs.

## Editable node tree
- `scenes/main.tscn`: `PetPage`, `PlannerPage`, `TopNav`.
- `scenes/planner_board.tscn`: `BoardMargin/Stack/ColumnRow` contains four editable columns. `EditorOverlay` holds the task form.
- `scenes/board_card.tscn`: every task card is an instance of this editable scene.
- `scenes/task_panel.tscn`: the task form is reused in editor-only mode; new `BoardSelect` lets you choose School, Personal, or Projects.
- `assets/ui/pixel_theme.tres`: the existing pixel-inspired button theme, now with softer checkbox states.

## What is not implemented yet
- Drag-and-drop reordering or free-positioned Milanote notes.
- Unlimited custom boards or nesting.
- Cross-device sync or mobile-specific layout.

The V5 board intentionally starts structured and simple, then we can add dragging, note cards, custom board names and phone layouts later.

## Saving
V5 uses the SAME `user://little_paw_save.json` as V4/V4.1. It adds a `board` field to tasks and defaults old tasks to Personal. Coins, upgrades, task completion, and focus statistics are preserved. Keep a backup of that save file for safety; the full V5 project may use a different Godot user-data folder if your folder/project settings differ.
