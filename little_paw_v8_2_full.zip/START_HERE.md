# Little Paw V4 — Import + First Lesson

## Open the full project

1. Download the **FULL PROJECT ZIP** and unzip it into a NEW folder.
2. Open Godot 4.7.2 Project Manager -> **Import**.
3. Select the extracted `project.godot` (do not use Godot's AssetLib Install for the ZIP).
4. Press F5 to run.
5. Click **TASKS -> + NEW TASK** and choose a task size and mode.
6. Click **FOCUS** and start a one-minute study session to test earning coins.

## Update your existing art-edited V3 project instead

1. **Back up your whole V3 project folder** and your save file.
2. Extract **CODE + UI PATCH ZIP** into the existing project directory, allowing replacement of its matching files.
3. Your `assets/`, `habitat.tscn`, and `pet.tscn` remain unchanged.
4. In the Godot editor, reopen `scenes/main.tscn` and run F5.

`scenes/task_panel.tscn`, `scenes/task_row.tscn`, and `scenes/focus_panel.tscn` will be replaced. If you've customized those three particular UI scenes, copy your changes into the V4 versions instead of overwriting blindly.

## First editing lesson

- `scenes/task_panel.tscn` -> select `FormPanel > FormScroll > FormPadding > FormStack` and edit labels, button sizes, and positions in the Inspector.
- `scenes/task_row.tscn` -> adjust how task sizes/rewards and dates look.
- `scenes/focus_panel.tscn` -> customize the timer font sizes and button positions.
- `scripts/game_state.gd` -> find `TASK_REWARDS` and change the reward tiers. They're `var`, not `const`.
- Your art is still separate in `assets/pets`, `assets/habitat`, and `scenes/habitat.tscn`.

## Testing checklist

- Create a small task due today, mark it done -> +15 coins once.
- Create a huge task due tomorrow -> visible in ALL TASKS today; after its due date, it will appear in TODAY.
- Create a daily habit (e.g. drink water) -> completing it earns +15 coins once per day; on the next calendar day it is available again.
- Edit an existing task to make it Medium -> updated reward for future completion, no extra reward for completed tasks.
- Create a task with an invalid date such as `2026-02-30` -> cannot save.
- Run a 1-minute study timer -> +2 coins. A break timer -> +0 coins.
- Restart the project -> tasks, coins, upgrades, and completed habits remain saved.

If a scene or script produces a Godot error, use the **Debugger > Errors** tab to copy the exact error and line number.
